# Screen Recorder → MP4

A zero-install, browser-based screen recorder that captures your screen with audio and saves **straight to MP4** — with a live disk-space HUD, automatic safeguards so you never lose a take, and unlimited recording length by streaming to disk.

Everything lives in a single self-contained `index.html`. **No build step, no dependencies, no server.** Just open it.

**▶ Live demo:** `https://<your-username>.github.io/<repo-name>/` _(enable GitHub Pages — see “Deploy” below)_

<!-- Tip: add a screenshot here for your portfolio, e.g. ![Screen Recorder](screenshot.png) -->

---

## Features

- **Screen video + audio** — system audio and/or microphone, mixed into a single track.
- **Saves to MP4** (H.264 / AAC) directly where the browser supports it; otherwise records WebM and converts to MP4 in-browser.
- **Unlimited length** — streams the file to disk *while* recording, so the only limit is free disk space.
- **Quality presets** — 720p / 1080p / native resolution, each with a matching bitrate.
- **Live HUD** on the preview: capture resolution, recorded size, estimated free space, and time-left — refreshed every second.
- **Pop-out counter** — a floating, always-on-top window (Document Picture-in-Picture) so you can watch the stats while you work in another app.
- **Safeguards so a recording is never silently lost:**
  - Auto-stops *before* the disk fills (keeps a flush buffer) and saves what was recorded.
  - Detects a frozen / stalled capture, auto-pauses, and resumes when frames return.
  - Warns when there is no audio source, when the stream goes dead mid-recording, and when a finished file turns out empty.
- **“Universal MP4”** repackages the file with `faststart` so it plays everywhere and starts instantly.
- Pause / resume, live timer, dark preview, and a cream-and-peach UI.

## How it works

| Concern | API used |
|---|---|
| Screen + system audio | `getDisplayMedia` |
| Microphone | `getUserMedia` |
| Mixing multiple audio sources | Web Audio API (`AudioContext` → `MediaStreamDestination`) |
| Encoding | `MediaRecorder` |
| Unlimited streaming to disk | File System Access API (`showSaveFilePicker` + `createWritable`) |
| Free-space readout | `navigator.storage.estimate()` |
| Freeze detection | `requestVideoFrameCallback` + track `mute` / `unmute` |
| Floating counter | Document Picture-in-Picture API |
| WebM → MP4 fallback & faststart | `@ffmpeg/ffmpeg` (WebAssembly) |

No frameworks — vanilla JavaScript in one HTML file.

## Run locally

Screen capture needs a secure context, so serve over `localhost` (or use the GitHub Pages link):

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

Opening the file directly via `file://` works for capture in Chrome, but the “save straight to disk” picker may be limited — a local server or GitHub Pages is recommended.

## Deploy (free live demo via GitHub Pages)

1. Push this repo to GitHub.
2. Repo **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **Deploy from a branch**.
4. Branch: **main**, folder: **/ (root)** → **Save**.
5. Wait ~1 minute, then open the URL it gives you. Because Pages serves over HTTPS, every feature works.

## Browser support

Best in **Chrome** and **Edge** (native MP4 recording, streaming to disk, floating counter). **Firefox** and **Safari** work via the WebM → MP4 conversion fallback.

## Known limitations (honest notes)

- **macOS:** browsers cannot capture system audio on macOS (an OS-level restriction), so on a Mac this app records **screen + microphone**. Capturing a single browser tab *can* grab that tab’s audio, but the picture may freeze if a video on the page enters fullscreen. To record fullscreen video **with its sound** on macOS, a native recorder plus a virtual audio device (e.g. BlackHole) is the reliable route.
- The free-space figure is the browser’s estimate, not an exact byte count.

## License

[MIT](LICENSE)
